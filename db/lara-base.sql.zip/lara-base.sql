-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2017 at 02:50 PM
-- Server version: 5.6.31-0ubuntu0.14.04.2
-- PHP Version: 5.6.28-1+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lara-base`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `title`, `start_date`, `end_date`) VALUES
(1, 'First Event', 'random title for events', '2017-04-19', '2017-04-21'),
(2, 'Second Event', 'random title for events', '2017-04-19', '2017-04-20'),
(3, 'Third ', 'random title for events', '2017-04-05', '2017-04-26'),
(4, 'Four', 'random title for events', '2017-04-18', '2017-04-20'),
(5, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(6, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(7, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(8, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(9, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(10, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(11, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(12, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(13, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(14, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(15, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(16, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(17, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(18, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(19, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(20, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(21, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(22, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(23, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(24, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(25, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(26, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(27, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(28, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(29, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(30, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(31, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(32, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(33, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(34, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(35, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(36, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(37, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(38, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(39, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(40, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(41, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(42, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(43, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(44, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(45, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(46, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(47, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(48, 'Six', 'random title for events', '2017-04-19', '2017-04-20'),
(49, 'Five', 'random title for events', '2017-04-19', '2017-04-26'),
(50, 'Six', 'random title for events', '2017-04-19', '2017-04-20');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assets` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `history_type_id_foreign` (`type_id`),
  KEY `history_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `history_types`
--

CREATE TABLE IF NOT EXISTS `history_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `history_types`
--

INSERT INTO `history_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'User', '2017-04-19 05:25:59', '2017-04-19 05:25:59'),
(2, 'Role', '2017-04-19 05:25:59', '2017-04-19 05:25:59');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2015_12_28_171741_create_social_logins_table', 1),
(4, '2015_12_29_015055_setup_access_tables', 1),
(5, '2016_07_03_062439_create_history_tables', 1),
(6, '2017_04_04_131153_create_sessions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'view-backend', 'View Backend', 1, '2017-04-19 05:25:58', '2017-04-19 05:25:58');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE IF NOT EXISTS `permission_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `all` tinyint(1) NOT NULL DEFAULT '0',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `all`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 1, 1, '2017-04-19 05:25:57', '2017-04-19 05:25:57'),
(2, 'Executive', 0, 2, '2017-04-19 05:25:57', '2017-04-19 05:25:57'),
(3, 'User', 0, 3, '2017-04-19 05:25:57', '2017-04-19 05:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE IF NOT EXISTS `role_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  KEY `role_user_role_id_foreign` (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('081htdbVJCFySEalA1kwL1qHDexfxarV71ZTt8bb', NULL, '192.192.7.51', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'ZXlKcGRpSTZJakJrT1VWR2QwMWNMelp6YUU0eE16Rm9jMFJEUWxsQlBUMGlMQ0oyWVd4MVpTSTZJbk4wY2toTVFWQm9lbXhuWEM5YVVFTlVTR3BUYVVKM1RHdFhOelpSUmtKcVdFZHJWWEpXWldWblMzUk1WbmRtTTFSYWVGRjZTek5LWldwYU5GRnlUM2cwZFdwaU0xd3ZkMlI2UzB0WFduWmpORUZ4VTFSMU5GcGFNRkl5U2t4bFJ6UnZPRVIzZEhwc1pGcHhUQ3R1Y1c5eFJYTk5lbmhZYXpoblEyTlJhVmROT1ZoNFFYSXhORmh3VWl0elRqUlRWbkprUjBWRFJFcHpka2sxVDNBM1IwdHNabXhrWTNCaEsyaGpSVVExWXpWeFhDOVhTM2Q1UlZkS1FUWXlPRVo2ZDI1dk1Wd3ZYQzltT1V4UVQxUmtPRUk1U2tOM09ISTNhR05SUkRReldYSnZWbWRTYkRCbVFTdGhTMDVQYTFwM1dUUk5UVkpjTDB4RWJXRnhlWFozYjA1Y0wxRkhhekZUYnpNNFZuUmlOSEZVZFRJd1pqZDNSVlZ5V1c5UGJFeHpkR05OTTNSSlZDdHhabk5VVjA5WlRFeGxjU3RjTDIwelREUlVhbU5WUlVwdWNrNVFNMDFyYmtod2RpdGNMME5ZWEM5dFRFZEhNa3RvYVhadE9XNUpRMnh4WldrNU5HTmxiRVppWjI1TFRYVlFWaXRFVlZaWVVXOU9iVk0xVG0xaWMxbEZWbVpTVDJaalkycFdXRmxOYmtsRlFYcGpTV2RGTWxZMFlscGhjWFJCUFQwaUxDSnRZV01pT2lJNVpqQmtOV1prT0dRMU5EZzBaamRrTXpobE5tSXhaRGd5WkdFek1XWm1OemhtTkRWaFlqY3lOR1k1TldNd01EbGxNamc1WTJZeE5XTmtaRE0zTkdJNEluMD0=', 1492690719),
('DG6kJiixDNmcdow4b9oqgSC1GAS7tSu3xhdP3m5s', 1, '192.192.7.51', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'ZXlKcGRpSTZJakpRU2tsSE56QXJWWEZ6YUU1Y0wwdHVYQzlhWVZoY0wzYzlQU0lzSW5aaGJIVmxJam9pTlVVelpDdFRlSGhCWWpsNWJrcHpRM1V6V0ZaelUzWmtkalZpT1ZSaU4yUlhSVzF2VFZoSWJDdGlURWR2VVVSU2NXc3phM01yZGs1WVRVdG9TM2xhY0VOS2NWd3ZYQzlKYVZWRlRGZG9RMXAyZFhKMVdETnNTVzk0WldaRmMyeFdVRUpXWkhOTFNHdGxkVGxoVVZGUE5tYzNaMlJ4VlcxSFlUVlFZVFJKSzI5b1Qwb3hSVlJSVkVORE0ycHVPRkJNUzBSVWEweHRUVlZTT1haYVlYaEplRGxWTURCSVVYQklTMnhjTDFobWFWZ3hUVWt6WVRoUlJYSktWbXcwWkRWWk5rRkRUVlZIYzNCUlEzUnZYQzlPUzFwTmJFVkpRbVpuWEM4NFpHRnVXV3BITkUwM2IxVXpYQzlCYVRSV1NEZHBiRmszVkhGMk9XZHpZMFZIYzNSVVltMTVXSFJ1WWxwd1hDOU1SRFYxTWsweFlWZFRXVzFzVFRaVFdVWkxUR1pTYzJ0WlhDOXlhbWQ0ZFZabU0wRnZORXhoZVhGaVdrOTJZMVE1SzFselFsWnljVWxUVDBoVFRsbDRhVGxSYmxwYVR6ZExSbTFPTlhSMk0xb3pRVGt3TVZoMWRHWTFNbHAzSzBGb1oyUmxjSGxCZEd0cFNucFlhRzFzYmtwTGVUZHRZMVJtV0V4SE4yUkJObmdyTVRBNFpqbHRVMFZDTTBOMVJ6UnhPVGhoZGxSb2QzcGpiVVZ0Wm5SbVNFOURSRXBOVG5kV09UUkRXbW8yWTNaRFNtMWpjMlpIWjJWbVIwY3dJaXdpYldGaklqb2lZekUyWVRSbVl6RmxNVEl6TldNek5tSTBObVU1T1RreE16ZzRNR0V4TWpFek1qQTJObUZsTTJNek1XSm1OekZrTXpWa1pXSXlOekppTlRka1pqSm1NQ0o5', 1492690244),
('DLDZL2GJ1ouEvAAhzSOHlOGdecyhRa1vdquUOpvF', 1, '192.192.7.51', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'ZXlKcGRpSTZJblJCTUVaNE5sWnRSRnBGT0d0RmFUbFZWRVpLV2xFOVBTSXNJblpoYkhWbElqb2lkakkyVWpKb1MzZGpSRUpvT0VsMVlYUTNPRWx3ZURsR1NHMHdNR1ZtZUd4UFEyYzJYQzlJU2pKVWFuVlphVWxHUlhWUVRVZzVXWG8yY1ZCRWEzZFVPRVJYWWpWT05teEhlVGxTYVd4aFpFaEJVRkpjTDFKUWFVVjZhSFkxYm5aRVhDOTBNVzQ1Vm5Sbk4wbEhaVTlKYkRCclNVeHhVM2R0V0RFMmIxTlhiQ3RIV1ZSSWRITmFkR0ZLTVhaRWFqbGpXbUZWY0RrMU9FbGNMMkZIYVdoMVdpczFNRXBvTnpOTWVraFhZM2t3UzJReGNtdFlOV3QyWW5oNGNFMW1kMDl5WldkeE4xd3ZNVVEwUWpCRU9FOXlUVXRrY1c4NVN6RkVjR0V5ZGt0alNVOXljVWd3Wlc5Y0x6Um1kalZSVTBSNmRteDFNSE41YW5OaUsydGpaRTlsWkUxTVYzWTRXSFJQZW5wWmRVRkJjRk4yUjI5MWVtZFBkRVZ5WTI1S1dHRjRiMlpJVVROa1FXTkhVWE5KUWpSMVdFZHpVMFpWTkV0T0syWnZTa0ZETlRVeUt6bFNLeXN3WTJRMVIwbDFVek5ZUnl0aVIycERiRGxOU0Zac1RGZDVURnd2ZWxoWVNsUnZaekZyUWtkalNUQk5OVmM0S3pNd05Wd3ZkMUZpVVRRNGRYRm5OVmwyUkRKaVRuVndUelpzTjJwY0wxd3ZOWGxvUlRrd05XdHNSa0YxVERGbGMyOXFTRWx5UjNKNmRraFphV2QzY2tKeWNGTTBhMWxqWTFKSWVETmtkWFJQYlhnNGJUY2lMQ0p0WVdNaU9pSTFZakJrTUdZeU9HRXlOVE5sWXpFM01tWTRZVEZtTWpZek9UazJaVFl4T0RRM01XSTNNalZqT0RnNE5XSXhZemN4WXpNeVlUWXdaV0l3TjJNeFpqTmlJbjA9', 1492690232),
('ohDfEtIJIGZz9NAoj5GNz6JWKTOjsuNFFKwPB74p', NULL, '192.192.7.51', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'ZXlKcGRpSTZJbE01UjJOcVRFczBWVTlNVFU5RVlVSnViVmxRWlVFOVBTSXNJblpoYkhWbElqb2ljRmRjTDNFd2IzWjRWbWhLWmtOWU1XSlFSVWx5ZEVGQlV6WlZTRUZ2YjNkQllrTnZaM0ZLYkVWMFJHVmhZVTVWYUdaNFQwOWFVVGR4VjJJM2JuWmtTelUwWjFoSWRuazFiRTVCTWxKVFlqaEpObmw1T0VOdGRreG1iSEZVTkc1dkt6ZDNWakZGVXprek5YSjROM2xjTHpCdGFXUk9aR0ZYVnpsdmRWd3ZjMGgwWVdsc2NTdFBkVFpCYlRKWU1tSnFiMjVQVkc5RWJqVldTR0ZHVVhKTlZHcFNVRWRET1V4cWRIQTVZM2xoUzNnNFoyUkhUbVpWTW05bWNreEtURkJWY21ZeE1XcHpia3h6UldkelUyVTBORk5oVmpkRlJWd3ZVa1pETXpSa2FXNWtaM3BtV0cxSk1qUnRTbXhCTjJ4QlZHdGNMM0ozTWpWa1VtMHlSVkpqZDFKcVprNXhTWFZ5V0RocVpYZ3hTalpFWlRjNVExVXJUSGRxWWpWV00xUjJkMjF5UVZOamJXbGxhVWx1VkZ3dlZVazlJaXdpYldGaklqb2lNVE01WVRZNFptSTFZV1F5T1RreU0yUTNOVEE1T0dKaE5qQmtPR0psTkdaaU56VTJNV05qTVdKaFlqQXpaRFl5TmpKaVlURmtaak0xTlRWbU4yRXlOaUo5', 1492758870);

-- --------------------------------------------------------

--
-- Table structure for table `social_logins`
--

CREATE TABLE IF NOT EXISTS `social_logins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_logins_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `confirmation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `confirmation_code`, `confirmed`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin Istrator', 'admin@admin.com', '$2y$10$AAhDP3h0bM0epABFtx1xpuNIGqYcKJ0lxkfrYCOOTEWCBh4p4pi9a', 1, 'd85697a3ed63d9ff2dacc801d401e959', 1, '0N8gJDKnn9ojbigG95Vsm3wUAGWuXKKnREvmC70QQaYfFZJwJSBdkJDEBfVL', '2017-04-19 05:25:57', '2017-04-19 05:25:57', NULL),
(2, 'Backend User', 'executive@executive.com', '$2y$10$JnYYHyXzBtxLPaItb2hOTugDZRJ.UZuBg8GY/AJoqSE0d7F1nYkhu', 1, '6b1ff622760f1455fc1bdbbc61b6bf71', 1, '0kRKBDPC1xMahT0y2QHdPnFXCXORuyxfs4vTv4GndQJpKDNypBpwcDU4XyFq', '2017-04-19 05:25:57', '2017-04-19 05:25:57', NULL),
(3, 'Default User', 'user@user.com', '$2y$10$W4GNl9dw4f5PUdBP.YGV4.ijg5aVtl/z60ib8nPIk/WCRXczVvppu', 1, '07d1799d71b6a001ed44a9f858eea58d', 1, 'wnqvi1Wbp1h5zl5QmEaSu4Ko4hTt3m0XsMx3ukaL5ynrD8Tvj1eHU8uM7YEs', '2017-04-19 05:25:57', '2017-04-19 05:25:57', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `history_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD CONSTRAINT `social_logins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
